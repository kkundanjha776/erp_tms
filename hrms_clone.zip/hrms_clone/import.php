<?php
require_once __DIR__ . '/core.php';
hrRequireCsrf();

$companyId = hrCompanyId($hrDb);
$importMode = $_POST['import_type'] ?? 'employees';
$report = null;

function hrNormalizeHeader(string $value): string {
    $value = strtolower(trim((string)$value));
    $value = preg_replace('/[^a-z0-9]+/', '_', $value);
    return trim((string)$value, '_');
}

function hrXlsxRows(string $file): array {
    $zip = new ZipArchive();
    if ($zip->open($file) !== true) {
        throw new RuntimeException('Excel file could not be read.');
    }

    $shared = [];
    $sharedStrings = $zip->getFromName('xl/sharedStrings.xml');
    if ($sharedStrings) {
        $xml = simplexml_load_string($sharedStrings);
        if ($xml) {
            foreach ($xml->si as $si) {
                $shared[] = (string)($si->t ?? implode('', array_map('strval', (array)$si->r)));
            }
        }
    }

    $sheet = $zip->getFromName('xl/worksheets/sheet1.xml');
    $zip->close();
    if (!$sheet) {
        throw new RuntimeException('Sheet1 was not found.');
    }

    $xml = simplexml_load_string($sheet);
    if (!$xml) {
        throw new RuntimeException('The uploaded Excel file could not be parsed.');
    }

    $xml->registerXPathNamespace('x', 'http://schemas.openxmlformats.org/spreadsheetml/2006/main');
    $rows = [];
    foreach ($xml->xpath('//x:sheetData/x:row') as $row) {
        $data = [];
        foreach ($row->c as $cell) {
            preg_match('/([A-Z]+)/', (string)$cell['r'], $matches);
            $col = 0;
            foreach (str_split($matches[1] ?? 'A') as $letter) {
                $col = $col * 26 + ord($letter) - 64;
            }

            $value = (string)$cell->v;
            if ((string)$cell['t'] === 's') {
                $value = $shared[(int)$value] ?? '';
            }
            $data[$col] = $value;
        }

        ksort($data);
        $rows[] = array_values($data);
    }

    return $rows;
}

function hrSheetRows(array $rows): array {
    if (!$rows) {
        return [];
    }

    $headers = array_map('hrNormalizeHeader', array_shift($rows));
    $out = [];
    foreach ($rows as $row) {
        $row = array_pad($row, count($headers), '');
        $out[] = array_combine($headers, array_slice($row, 0, count($headers)));
    }

    return $out;
}

function hrNormalizeStatus(string $value): string {
    $map = [
        'present' => 'Present',
        'late' => 'Late',
        'absent' => 'Absent',
        'paid leave' => 'Paid Leave',
        'paid_leave' => 'Paid Leave',
        'work from home' => 'Work From Home',
        'wfh' => 'Work From Home',
        'holiday' => 'Paid Leave',
        'leave' => 'Paid Leave'
    ];
    $key = strtolower(trim((string)$value));
    return $map[$key] ?? ucfirst(str_replace('_', ' ', $key));
}

function hrNormalizeDate(string $value): string {
    $value = trim((string)$value);
    if ($value === '') {
        return '';
    }
    $value = str_replace('/', '-', $value);
    $ts = strtotime($value);
    return $ts !== false ? date('Y-m-d', $ts) : '';
}

function hrNormalizeTime(?string $value): ?string {
    $value = trim((string)($value ?? ''));
    if ($value === '') {
        return null;
    }

    if (preg_match('/^\d{1,2}:\d{2}(:\d{2})?$/', $value)) {
        $parts = explode(':', $value);
        $hours = (int)($parts[0] ?? 0);
        $minutes = (int)($parts[1] ?? 0);
        $seconds = (int)($parts[2] ?? 0);
        return sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);
    }

    $ts = strtotime($value);
    return $ts !== false ? date('H:i:s', $ts) : null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (empty($_FILES['sheet']['tmp_name'])) {
            throw new RuntimeException('Choose a CSV or XLSX file first.');
        }

        $ext = strtolower(pathinfo($_FILES['sheet']['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['csv', 'xlsx'], true)) {
            throw new RuntimeException('Only .csv and .xlsx files are supported.');
        }

        $importMode = $_POST['import_type'] ?? 'employees';
        $raw = $ext === 'csv'
            ? array_map('str_getcsv', file($_FILES['sheet']['tmp_name'], FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES))
            : hrXlsxRows($_FILES['sheet']['tmp_name']);

        if (!$raw) {
            throw new RuntimeException('The uploaded file is empty or contains no rows.');
        }

        $rows = hrSheetRows($raw);
        if (!$rows) {
            throw new RuntimeException('The uploaded file has no usable data rows.');
        }

        $report = ['created' => 0, 'updated' => 0, 'errors' => []];

        if ($importMode === 'attendance') {
            foreach ($rows as $index => $row) {
                $employeeCode = trim((string)($row['employee_code'] ?? $row['employee_id'] ?? ''));
                if ($employeeCode === '') {
                    $report['errors'][] = 'Row ' . ($index + 2) . ': employee_code is required.';
                    continue;
                }

                $employee = hrEmployeeByCode($hrDb, $employeeCode);
                if (!$employee) {
                    $report['errors'][] = 'Row ' . ($index + 2) . ': employee code ' . htmlspecialchars($employeeCode) . ' was not found.';
                    continue;
                }

                $attendanceDate = hrNormalizeDate((string)($row['attendance_date'] ?? $row['date'] ?? ''));
                if ($attendanceDate === '') {
                    $report['errors'][] = 'Row ' . ($index + 2) . ': attendance_date is required.';
                    continue;
                }

                $status = hrNormalizeStatus((string)($row['status'] ?? $row['attendance_status'] ?? 'Present'));
                $checkIn = hrNormalizeTime((string)($row['check_in'] ?? $row['in_time'] ?? ''));
                $checkOut = hrNormalizeTime((string)($row['check_out'] ?? $row['out_time'] ?? ''));

                $checkInSql = $checkIn === null ? 'NULL' : "'" . $hrDb->real_escape_string($checkIn) . "'";
                $checkOutSql = $checkOut === null ? 'NULL' : "'" . $hrDb->real_escape_string($checkOut) . "'";
                $sql = "INSERT INTO hr_attendance (company_id, employee_id, attendance_date, status, check_in, check_out)
                        VALUES (
                            " . (int)$companyId . ",
                            " . (int)$employee['id'] . ",
                            '" . $hrDb->real_escape_string($attendanceDate) . "',
                            '" . $hrDb->real_escape_string($status) . "',
                            $checkInSql,
                            $checkOutSql
                        )
                        ON DUPLICATE KEY UPDATE
                            status = VALUES(status),
                            check_in = COALESCE(VALUES(check_in), check_in),
                            check_out = COALESCE(VALUES(check_out), check_out)";

                if ($hrDb->query($sql)) {
                    $report['updated']++;
                } else {
                    $report['errors'][] = 'Row ' . ($index + 2) . ': could not save attendance.';
                }
            }
        } else {
            foreach ($rows as $index => $row) {
                $code = trim((string)($row['employee_code'] ?? ''));
                $first = trim((string)($row['first_name'] ?? ''));
                if ($code === '' || $first === '') {
                    $report['errors'][] = 'Row ' . ($index + 2) . ': employee_code and first_name are required.';
                    continue;
                }

                $last = trim((string)($row['last_name'] ?? ''));
                $email = trim((string)($row['email'] ?? ''));
                $department = trim((string)($row['department'] ?? ''));
                $designation = trim((string)($row['designation'] ?? ''));
                $joinDate = hrNormalizeDate((string)($row['join_date'] ?? '')) ?: date('Y-m-d');
                $basic = (float)($row['basic_salary'] ?? 0);
                $hra = (float)($row['hra'] ?? 0);
                $allowance = (float)($row['allowance'] ?? 0);
                $role = strtoupper(trim((string)($row['role'] ?? 'Employee')));
                $passwordHash = password_hash('123456', PASSWORD_DEFAULT);
                $dob = hrNormalizeDate((string)($row['dob'] ?? ''));
                $gender = trim((string)($row['gender'] ?? ''));
                $address = trim((string)($row['address'] ?? ''));
                $city = trim((string)($row['city'] ?? ''));
                $state = trim((string)($row['state'] ?? ''));
                $country = trim((string)($row['country'] ?? 'India'));
                $qualification = trim((string)($row['qualification'] ?? ''));
                $experienceYear = (float)($row['experience_years'] ?? 0);
                $emergencyName = trim((string)($row['emergency_contact_name'] ?? ''));
                $emergencyPhone = trim((string)($row['emergency_contact_phone'] ?? ''));
                $aadhar = trim((string)($row['aadhar'] ?? ''));
                $passport = trim((string)($row['passport'] ?? ''));

                $sql = "INSERT INTO hr_employees (
                            company_id, employee_code, first_name, last_name, email, department, designation, join_date, basic_salary, hra, allowance, role, password_hash, dob, gender, address, city, state, country, qualification, experience_years, emergency_contact_name, emergency_contact_phone, aadhar, passport
                        ) VALUES (
                            " . (int)$companyId . ",
                            '" . $hrDb->real_escape_string($code) . "',
                            '" . $hrDb->real_escape_string($first) . "',
                            '" . $hrDb->real_escape_string($last) . "',
                            '" . $hrDb->real_escape_string($email) . "',
                            '" . $hrDb->real_escape_string($department) . "',
                            '" . $hrDb->real_escape_string($designation) . "',
                            '" . $hrDb->real_escape_string($joinDate) . "',
                            " . (float)$basic . ",
                            " . (float)$hra . ",
                            " . (float)$allowance . ",
                            '" . $hrDb->real_escape_string($role) . "',
                            '" . $hrDb->real_escape_string($passwordHash) . "',
                            '" . $hrDb->real_escape_string($dob ?: '') . "',
                            '" . $hrDb->real_escape_string($gender) . "',
                            '" . $hrDb->real_escape_string($address) . "',
                            '" . $hrDb->real_escape_string($city) . "',
                            '" . $hrDb->real_escape_string($state) . "',
                            '" . $hrDb->real_escape_string($country) . "',
                            '" . $hrDb->real_escape_string($qualification) . "',
                            " . (float)$experienceYear . ",
                            '" . $hrDb->real_escape_string($emergencyName) . "',
                            '" . $hrDb->real_escape_string($emergencyPhone) . "',
                            '" . $hrDb->real_escape_string($aadhar) . "',
                            '" . $hrDb->real_escape_string($passport) . "'
                        )
                        ON DUPLICATE KEY UPDATE
                            first_name = VALUES(first_name),
                            last_name = VALUES(last_name),
                            email = VALUES(email),
                            department = VALUES(department),
                            designation = VALUES(designation),
                            join_date = VALUES(join_date),
                            basic_salary = VALUES(basic_salary),
                            hra = VALUES(hra),
                            allowance = VALUES(allowance),
                            role = VALUES(role),
                            password_hash = VALUES(password_hash),
                            dob = VALUES(dob),
                            gender = VALUES(gender),
                            address = VALUES(address),
                            city = VALUES(city),
                            state = VALUES(state),
                            country = VALUES(country),
                            qualification = VALUES(qualification),
                            experience_years = VALUES(experience_years),
                            emergency_contact_name = VALUES(emergency_contact_name),
                            emergency_contact_phone = VALUES(emergency_contact_phone),
                            aadhar = VALUES(aadhar),
                            passport = VALUES(passport)";

                if ($hrDb->query($sql)) {
                    $insertedId = $hrDb->insert_id ?: $hrDb->query("SELECT id FROM hr_employees WHERE company_id=$companyId AND employee_code='" . $hrDb->real_escape_string($code) . "' LIMIT 1")->fetch_assoc()['id'] ?? 0;
                    if ($insertedId) {
                        $payCycle = trim((string)($row['pay_cycle'] ?? 'Monthly'));
                        $gross = (float)($row['gross_salary'] ?? $basic);
                        $bankName = trim((string)($row['bank_name'] ?? ''));
                        $bankAccount = trim((string)($row['bank_account'] ?? ''));
                        $notes = trim((string)($row['declaration_notes'] ?? ''));
                        $assetType = trim((string)($row['asset_type'] ?? ''));
                        $assetName = trim((string)($row['asset_name'] ?? ''));
                        $assetSerial = trim((string)($row['asset_serial_number'] ?? ''));
                        $assetDate = hrNormalizeDate((string)($row['asset_assigned_date'] ?? '')) ?: date('Y-m-d');
                        $hrDb->query("INSERT INTO hr_employee_payroll_setup (company_id, employee_id, pay_cycle, gross_salary, net_salary, effective_date, bank_name, bank_account, notes) VALUES ($companyId, $insertedId, '" . $hrDb->real_escape_string($payCycle) . "', " . $gross . ", " . $gross . ", '" . $hrDb->real_escape_string($joinDate) . "', '" . $hrDb->real_escape_string($bankName) . "', '" . $hrDb->real_escape_string($bankAccount) . "', '" . $hrDb->real_escape_string($notes) . "') ON DUPLICATE KEY UPDATE pay_cycle=VALUES(pay_cycle), gross_salary=VALUES(gross_salary), net_salary=VALUES(net_salary), effective_date=VALUES(effective_date), bank_name=VALUES(bank_name), bank_account=VALUES(bank_account), notes=VALUES(notes)");
                        if ($assetName !== '') {
                            $hrDb->query("INSERT INTO hr_employee_assets (company_id, employee_id, asset_type, asset_name, serial_number, assigned_date, status, issued_by, notes) VALUES ($companyId, $insertedId, '" . $hrDb->real_escape_string($assetType) . "', '" . $hrDb->real_escape_string($assetName) . "', '" . $hrDb->real_escape_string($assetSerial) . "', '" . $hrDb->real_escape_string($assetDate) . "', 'Assigned', 'CSV Import', '" . $hrDb->real_escape_string($notes) . "')");
                        }
                    }
                    $report['created']++;
                } else {
                    $report['errors'][] = 'Row ' . ($index + 2) . ': duplicate employee code or invalid data.';
                }
            }
        }
    } catch (Throwable $e) {
        $report = ['created' => 0, 'updated' => 0, 'errors' => [$e->getMessage()]];
    }
}

hrPageStart('Excel import');
?>
<div class="page-head">
    <div>
        <h2>Bulk import</h2>
        <p>Upload employee or attendance data for the selected company.</p>
    </div>
    <a class="button secondary" href="<?= $importMode === 'attendance' ? 'attendance_import_template.csv' : 'employee_import_template.csv' ?>" download>
        <i data-lucide="download"></i>Download template
    </a>
</div>

<div class="panel">
    <div class="notice">
        <b>Import mode:</b>
        <select name="import_type" form="import-form">
            <option value="employees" <?= $importMode === 'employees' ? 'selected' : '' ?>>Employee import</option>
            <option value="attendance" <?= $importMode === 'attendance' ? 'selected' : '' ?>>Attendance import</option>
        </select>
    </div>

    <form id="import-form" method="post" enctype="multipart/form-data">
        <input type="hidden" name="csrf" value="<?= hrCsrf() ?>">

        <div class="file-drop">
            <i data-lucide="file-up"></i>
            <strong>Upload spreadsheet</strong>
            <p>Accepts .csv and .xlsx files. Attendance import supports Excel and biometric-style columns.</p>
            <input name="sheet" type="file" accept=".xlsx,.csv" required>
        </div>

        <div class="form-actions">
            <button class="button"><i data-lucide="upload"></i>Validate & import</button>
        </div>
    </form>

    <?php if ($report): ?>
        <div class="payroll-totals">
            <div><span>Created</span><b><?= (int)($report['created'] ?? 0) ?></b></div>
            <div><span>Updated</span><b><?= (int)($report['updated'] ?? 0) ?></b></div>
            <div><span>Rejected rows</span><b><?= count($report['errors'] ?? []) ?></b></div>
        </div>

        <?php if (($report['errors'] ?? []) !== []): ?>
            <div class="notice">
                <?php foreach ($report['errors'] as $error): ?>
                    <?= htmlspecialchars($error) ?><br>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<?php hrPageEnd(); ?>
